load('../data/airport/sun_aerinlrdodkqnypz.mat','wordMap');
getImageFeatures(wordMap, 60);
