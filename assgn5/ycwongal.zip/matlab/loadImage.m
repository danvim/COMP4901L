function [I] = loadImage()
    I = imread('../data/airport/sun_aerinlrdodkqnypz.jpg');
%    I = imread('../data/airport/sun_agfgtuuejaamawrv.jpg');
%    I = imread('../data/airport/sun_afijvcdfbowiakrd.jpg');
%    I = imread('../data/airport/sun_afydjxkwpncynvos.jpg');
%    I = imread('../data/airport/sun_agfgqhjpfoisexbu.jpg');
