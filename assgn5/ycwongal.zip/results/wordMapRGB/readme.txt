for each images,
left is orginal image,
center is random word map to RGB,
right is harris word map to RGB.
