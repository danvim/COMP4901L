function [ w ] = get_weights( p, q, hue )
