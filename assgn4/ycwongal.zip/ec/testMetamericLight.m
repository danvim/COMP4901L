
load('../data/bananas.mat');
T = metamericLight(ripe,overripe);
display(T)
