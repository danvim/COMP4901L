function [im] = getim
im = imread('../data/img01.jpg');
im = double(im);
end
